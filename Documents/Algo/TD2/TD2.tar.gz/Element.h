#ifndef ELEMENT_H_INCLUDED
#define ELEMENT_H_INCLUDED

typedef int element;

#endif // ELEMENT_H_INCLUDED
