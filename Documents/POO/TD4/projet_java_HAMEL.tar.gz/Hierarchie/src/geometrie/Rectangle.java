package geometrie;

public class Rectangle extends Quadrilatere {
	public Rectangle(){
		System.out.println("Constructeur de Rectangle");
	}

}
