var searchData=
[
  ['write_5fcode',['write_code',['../namespacechallenge.html#a1853eb3e006f638f42c1bd795a548fd2',1,'challenge']]],
  ['write_5fcode_5fwith_5ftable',['write_code_with_table',['../namespacechallenge.html#ab2d2b10f497543efd9ae0bd87007f9d9',1,'challenge']]]
];
