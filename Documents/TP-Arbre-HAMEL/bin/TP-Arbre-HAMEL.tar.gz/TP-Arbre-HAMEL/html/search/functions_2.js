var searchData=
[
  ['couperpetits',['couperPetits',['../arbre_8c.html#a1bda5af24df7525c287b06c8e7412e52',1,'couperPetits(arbre *a, int hauteur):&#160;arbre.c'],['../arbre_8h.html#a1bda5af24df7525c287b06c8e7412e52',1,'couperPetits(arbre *a, int hauteur):&#160;arbre.c']]],
  ['creernoeud',['creerNoeud',['../arbre_8c.html#af433ad9723fdaeb29f5907993373fbba',1,'creerNoeud(int v):&#160;arbre.c'],['../arbre_8h.html#af433ad9723fdaeb29f5907993373fbba',1,'creerNoeud(int v):&#160;arbre.c']]]
];
