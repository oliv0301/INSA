var searchData=
[
  ['_5f_5finit_5f_5f',['__init__',['../classchallenge_1_1Cell.html#a732f95afef18f59105e8afa84ba9be89',1,'challenge::Cell']]]
];
