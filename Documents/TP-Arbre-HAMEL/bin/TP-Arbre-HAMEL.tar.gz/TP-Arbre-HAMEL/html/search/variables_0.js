var searchData=
[
  ['challenge',['challenge',['../namespacechallenge.html#acbb95559d4ccdc708dbe25b0e3f4fdc1',1,'challenge']]]
];
