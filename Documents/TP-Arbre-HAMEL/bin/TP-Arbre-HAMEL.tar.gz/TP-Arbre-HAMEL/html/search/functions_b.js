var searchData=
[
  ['shiftespace',['shiftEspace',['../arbre_8c.html#a20b76dcb3349edeff8232e28bdc8ef92',1,'shiftEspace(double delta, int niveaumax, int niveau, int width):&#160;arbre.c'],['../structures_8h.html#a20b76dcb3349edeff8232e28bdc8ef92',1,'shiftEspace(double delta, int niveaumax, int niveau, int width):&#160;arbre.c']]],
  ['somme',['somme',['../arbre_8c.html#ac0605f522186a91eeaf09cb68cd6cc5a',1,'somme(arbre *r):&#160;arbre.c'],['../arbre_8h.html#ac0605f522186a91eeaf09cb68cd6cc5a',1,'somme(arbre *r):&#160;arbre.c']]]
];
